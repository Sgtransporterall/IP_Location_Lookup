# IP_Location_Lookup

Tested the code by PHP version 5.5.12 and MySQL version 5.6.17. 

You need to change the database information in connection.php, before you run the code.
